// 🎨 WhatsApp-স্টাইল ইমেজ-এডিটর — ছবির উপর ফ্রিহ্যান্ড ড্র (pen)।
//  • পেন-সাইজ: ছোট → বড় (৪ ধাপ, WhatsApp-এর মতো ডিসক্রিট সাইজ)
//  • কালার: iOS/WhatsApp প্যালেট (১০টা)
//  • আন্ডু (স্ট্রোক-স্ট্যাক), বাতিল, সেন্ড
//  • সেন্ড করলে এনক্রিপ্টেড-আপলোড হয়ে নতুন image-মেসেজ যায় — অরিজিনাল
//    মেসেজের রিপ্লাই হিসেবে (user A ছবি দিলে user B এডিট করে ফেরত পাঠাতে পারবে)
import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { useUi } from '../../stores/ui'
import { useChats } from '../../stores/chats'
import { uploadEncrypted } from '../../lib/media'
import { useT } from '../../lib/i18n'
import { IcX, IcSend, IcPencil } from '../../lib/icons'

// WhatsApp-এর ড্র-প্যালেট
const PALETTE = ['#ffffff', '#000000', '#fe0303', '#ff9f0a', '#ffd60a', '#30d158', '#64d2ff', '#0a84ff', '#bf5af2', '#ff375f']
// পেন-সাইজ (ডিসপ্লে-px; ক্যানভাস-স্কেলে গুণ হয়) — ছোট/মিডিয়াম/বড়/এক্সট্রা-বড়
const SIZES = [3, 6, 10, 16]

interface Stroke {
  color: string
  size: number
  points: { x: number; y: number }[]
}

export default function ImageEditor() {
  const editor = useUi((s) => s.imageEditor)
  const closeImageEditor = useUi((s) => s.closeImageEditor)
  const toast = useUi((s) => s.toast)
  const t = useT()
  const [color, setColor] = useState('#fe0303')
  const [sizeIdx, setSizeIdx] = useState(1)
  const [strokes, setStrokes] = useState<Stroke[]>([])
  const [sending, setSending] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imgRef = useRef<HTMLImageElement | null>(null)
  const drawing = useRef<Stroke | null>(null)

  // ছবি লোড → ক্যানভাসে বেস-লেয়ার
  useEffect(() => {
    if (!editor) return
    setStrokes([])
    setSending(false)
    const img = new Image()
    img.onload = () => {
      imgRef.current = img
      repaint()
    }
    img.onerror = () => toast(t('mediaLoadFail'))
    img.src = editor.url
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor?.url])

  // ESC = বাতিল
  useEffect(() => {
    if (!editor) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeImageEditor() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor])

  if (!editor) return null

  function repaint() {
    const c = canvasRef.current
    const img = imgRef.current
    if (!c || !img) return
    c.width = img.naturalWidth
    c.height = img.naturalHeight
    const ctx = c.getContext('2d')!
    ctx.clearRect(0, 0, c.width, c.height)
    ctx.drawImage(img, 0, 0)
    // ডিসপ্লে-সাইজ → ক্যানভাস-স্কেল ফ্যাক্টর (পেন-সাইজ স্ক্রিনে একই মোটা দেখায়)
    const scale = c.width / (c.getBoundingClientRect().width || c.width)
    for (const s of strokes) drawStroke(ctx, s, scale)
    if (drawing.current) drawStroke(ctx, drawing.current, scale)
  }

  function drawStroke(ctx: CanvasRenderingContext2D, s: Stroke, scale: number) {
    if (s.points.length < 1) return
    ctx.strokeStyle = s.color
    ctx.fillStyle = s.color
    ctx.lineWidth = s.size * scale
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    // সিঙ্গেল-ট্যাপ = ডট
    if (s.points.length === 1) {
      const p = s.points[0]
      ctx.beginPath()
      ctx.arc(p.x, p.y, (s.size * scale) / 2, 0, Math.PI * 2)
      ctx.fill()
      return
    }
    ctx.beginPath()
    ctx.moveTo(s.points[0].x, s.points[0].y)
    // মিডপয়েন্ট-কোয়াড্রাটিক — হাত কাঁপা লাইন মসৃণ হয়
    for (let i = 1; i < s.points.length - 1; i++) {
      const mx = (s.points[i].x + s.points[i + 1].x) / 2
      const my = (s.points[i].y + s.points[i + 1].y) / 2
      ctx.quadraticCurveTo(s.points[i].x, s.points[i].y, mx, my)
    }
    ctx.lineTo(s.points[s.points.length - 1].x, s.points[s.points.length - 1].y)
    ctx.stroke()
  }

  function posOf(e: React.PointerEvent): { x: number; y: number } {
    const c = canvasRef.current!
    const r = c.getBoundingClientRect()
    return { x: ((e.clientX - r.left) / r.width) * c.width, y: ((e.clientY - r.top) / r.height) * c.height }
  }

  function onDown(e: React.PointerEvent) {
    if (sending) return
    ;(e.target as HTMLElement).setPointerCapture?.(e.pointerId)
    drawing.current = { color, size: SIZES[sizeIdx], points: [posOf(e)] }
    repaint()
  }

  function onMove(e: React.PointerEvent) {
    if (!drawing.current) return
    drawing.current.points.push(posOf(e))
    repaint()
  }

  function onUp() {
    if (!drawing.current) return
    const done = drawing.current
    drawing.current = null
    setStrokes((s) => [...s, done])
  }

  function undo() {
    setStrokes((s) => s.slice(0, -1))
  }

  // সেন্ড — এনক্রিপ্টেড-আপলোড + রিপ্লাইসহ নতুন image-মেসেজ
  async function send() {
    const c = canvasRef.current
    if (!c || sending) return
    setSending(true)
    try {
      const blob: Blob | null = await new Promise((res) => c.toBlob((b) => res(b), 'image/jpeg', 0.92))
      if (!blob) throw new Error('encode failed')
      const name = (editor.name || 'image').replace(/\.[a-z0-9]+$/i, '') + '-edited.jpg'
      const meta = await uploadEncrypted(blob, name, 'image/jpeg')
      meta.w = c.width
      meta.h = c.height
      await useChats.getState().sendDraft(editor.chatId, {
        type: 'image',
        media: meta,
        replyTo: editor.replyTo
          ? { id: editor.replyTo.id, body: editor.replyTo.body || '(image)', senderId: editor.replyTo.senderId }
          : undefined,
      })
      toast(t('editedImageSent'))
      closeImageEditor()
    } catch (e: any) {
      toast(t('uploadFailed', { msg: e?.message || '' }))
    } finally {
      setSending(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[88] bg-black/95 flex flex-col select-none touch-none"
    >
      {/* হেডার — নাম + বন্ধ */}
      <div className="flex items-center gap-3 px-4 h-14 shrink-0 text-white">
        <button onClick={closeImageEditor} className="p-2 rounded-full hover:bg-white/10 transition"><IcX size={22} /></button>
        <div className="flex-1 min-w-0 text-[15px] font-medium truncate">{t('editImageTitle')}</div>
        <button onClick={undo} disabled={!strokes.length}
          className={`px-3 py-1.5 rounded-xl text-[13px] font-semibold transition ${strokes.length ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-white/5 text-white/30 cursor-not-allowed'}`}>
          {t('undoBtn')}
        </button>
      </div>

      {/* ক্যানভাস — ছবি + ড্র-লেয়ার (যে-কোনো জায়গায় আঙুল/পেন চালালেই আঁকা) */}
      <div className="flex-1 min-h-0 flex items-center justify-center p-3">
        <canvas
          ref={canvasRef}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
          className="max-w-full max-h-full object-contain rounded-lg shadow-2xl cursor-crosshair"
          style={{ touchAction: 'none' }}
        />
      </div>

      {/* টুলবার — WhatsApp-স্টাইল: পেন-সাইজ + কালার + সেন্ড */}
      <div className="shrink-0 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 bg-black/60 backdrop-blur border-t border-white/10">
        {/* পেন-সাইজ — WhatsApp-এর মতো বড় থেকে ছোট ডট */}
        <div className="flex items-center justify-center gap-4 py-2.5">
          {SIZES.map((s, i) => (
            <button key={s} onClick={() => setSizeIdx(i)} title={t('penSize')}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition ${sizeIdx === i ? 'bg-white/15 scale-110' : 'hover:bg-white/10'}`}>
              <span
                className="rounded-full"
                style={{
                  width: Math.max(6, s * 1.6), height: Math.max(6, s * 1.6),
                  background: sizeIdx === i ? color : '#ffffffcc',
                }} />
            </button>
          ))}
        </div>
        {/* কালার-প্যালেট + সেন্ড */}
        <div className="flex items-center gap-2 pb-1.5">
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {PALETTE.map((c) => (
              <button key={c} onClick={() => setColor(c)} title={c}
                className={`w-8 h-8 rounded-full shrink-0 transition-transform ${color === c ? 'ring-2 ring-white scale-110' : 'hover:scale-105'}`}
                style={{ background: c, boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.35)' }} />
            ))}
          </div>
          <motion.button whileTap={{ scale: 0.88 }} onClick={send} disabled={sending}
            className="w-12 h-12 rounded-full bg-[#00a884] text-white flex items-center justify-center shadow-lg shadow-emerald-900/40 shrink-0 disabled:opacity-50">
            {sending ? <span className="text-xs font-bold">…</span> : <IcSend size={22} />}
          </motion.button>
        </div>
        {/* হিন্ট */}
        <div className="flex items-center justify-center gap-1.5 pb-1 text-[11px] text-white/40">
          <IcPencil size={12} /> {t('drawHint')}
        </div>
      </div>
    </motion.div>
  )
}
