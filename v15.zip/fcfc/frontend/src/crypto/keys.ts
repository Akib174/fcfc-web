// আইডেন্টিটি কী জেনারেশন ও স্টোরেজ (সব ক্লায়েন্ট-সাইডে, IndexedDB-তে)।
// X25519 → ডিফি-হেলম্যান, ECDSA P-256 → সিগনেড-প্রিকি যাচাই।
//
// 🩺 Round 22 — মেসেজ-পাঠানো "!"-বাগের আসল কারণ এখানেই ছিল:
// আগে X25519-অসমর্থিত ব্রাউজারে (পুরনো Edge/Chrome<133, কিছু Firefox)
// নিজের কী P-256-এ বানানো হতো — অথচ পিয়ারের কী X25519 হলে সেটা
// ইম্পোর্টই করা যেত না (NotSupportedError: Unrecognized namedCurve /
// OperationError) → এনক্রিপশন ব্যর্থ → "!"। সমাধান তিন স্তরে:
//   1) x25519.ts-এ pure-JS X25519 — ব্রাউজার নির্বিশেষে চলে
//   2) WebCrypto-র যেকোনো ধাপ ব্যর্থ হলে JsKey পলিফিল + JS-গণনায় নামা
//   3) X3DH-এ প্রেরক পিয়ারের কার্ভে নিজের কী অ্যাডাপ্ট করে (x3dh.ts)
import { idb } from '../lib/db'
import { b64u, b64uToBytes } from '../lib/utils'
import { x25519Generate, x25519Shared } from './x25519'

export const SIGN_ALG = { name: 'ECDSA', namedCurve: 'P-256' } as EcKeyGenParams
const X25519_ALG = { name: 'ECDH', namedCurve: 'X25519' } as EcKeyGenParams
const P256_DH_ALG = { name: 'ECDH', namedCurve: 'P-256' } as EcKeyGenParams

export type DhCurve = 'X25519' | 'P-256'

// ── টেস্ট হুক (শুধু URL প্যারামে, প্রোডাকশনে নিষ্ক্রিয়) ──
//   ?jsx25519=1    → WebCrypto-X25519 বাদ দিয়ে জোর করে pure-JS পথ (পুরনো-
//                    ব্রাউজার সিমুলেশন — ফল একই, পথ আলাদা)
//   ?dhcurve=P-256 → নতুন রেজিস্ট্রেশন লেগেসি P-256 বান্ডেলে (আগের-
//                    বাগের-যুগের ব্যবহারকারীর সিমুলেশন)
const HOOKS = (() => {
  try {
    const q = new URLSearchParams(location.search)
    return {
      forceJsX25519: q.has('jsx25519'),
      regCurve: (q.get('dhcurve') === 'P-256' ? 'P-256' : 'X25519') as DhCurve,
    }
  } catch {
    return { forceJsX25519: false, regCurve: 'X25519' as DhCurve }
  }
})()

// ── JWK রেজিস্ট্রি: প্রতিটি কী-অবজেক্টের উৎস-JWK মনে রাখা হয়।
// WebCrypto-র deriveBits হঠাৎ ব্যর্থ হলে (Firefox OperationError) raw
// বাইট দরকার হয় — তখন রি-এক্সপোর্ট না করে এখান থেকেই পাওয়া যায়। ──
const jwkStore = new WeakMap<object, JsonWebKey>()
export function jwkOf(k: object): JsonWebKey | undefined {
  return jwkStore.get(k)
}

export function jwkCurve(jwk: JsonWebKey | null | undefined): DhCurve | null {
  if (!jwk) return null
  if (jwk.crv === 'P-256') return 'P-256'
  if (jwk.crv === 'X25519') return 'X25519'
  return null
}

// WebCrypto যেখানে X25519 ইম্পোর্ট/জেনারেট করতে পারে না — সেখানে এই
// কী-অবজেক্ট বসে। দেখতে CryptoKey-এর মতোই (type/algorithm/usages),
// ভেতরে JWK বহন করে; dh() এটা দেখলে সরাসরি pure-JS গণনায় যায়।
export class JsKey implements CryptoKey {
  readonly algorithm: EcKeyGenParams
  readonly extractable = true
  readonly usages: KeyUsage[]
  readonly type: KeyType
  constructor(jwk: JsonWebKey, type: 'public' | 'private', usages: KeyUsage[]) {
    this.type = type
    this.usages = usages
    this.algorithm = jwk.crv === 'X25519' ? X25519_ALG : P256_DH_ALG
    jwkStore.set(this, jwk)
  }
}

export const genSign = () => crypto.subtle.generateKey(SIGN_ALG, true, ['sign', 'verify'])

// Chrome/Edge এক্সপোর্টেড JWK-তে `key_ops: []` দেয় — সেটা থাকলে importKey
// "key_ops inconsistent" DataError দেয়। তাই ইম্পোর্টের আগে key_ops বাদ দিই।
function cleanJwk(jwk: JsonWebKey): JsonWebKey {
  const { key_ops, ...rest } = jwk as JsonWebKey & { key_ops?: unknown }
  return { ...rest, ext: true } as JsonWebKey
}

function jsKeyFromJwk(c: JsonWebKey, type: 'public' | 'private', usages: KeyUsage[]): CryptoKey {
  if (!c.x) throw new Error('X25519 JWK missing "x"')
  if (type === 'private' && !c.d) throw new Error('X25519 private JWK missing "d"')
  return new JsKey(c, type, usages)
}

export async function importPubJwk(jwk: JsonWebKey, usages: KeyUsage[] = []): Promise<CryptoKey> {
  const c = cleanJwk(jwk)
  if (c.crv === 'X25519') {
    if (!HOOKS.forceJsX25519) {
      try {
        const k = await crypto.subtle.importKey('jwk', c, X25519_ALG, true, usages)
        jwkStore.set(k, c)
        return k
      } catch {
        // NotSupportedError (পুরনো Edge/Chrome) / OperationError (Firefox) → JsKey
      }
    }
    return jsKeyFromJwk(c, 'public', usages)
  }
  const alg = usages.includes('verify') ? SIGN_ALG : P256_DH_ALG
  const k = await crypto.subtle.importKey('jwk', c, alg, true, usages)
  jwkStore.set(k, c)
  return k
}

export async function importPrivJwk(jwk: JsonWebKey, usages: KeyUsage[]): Promise<CryptoKey> {
  const c = cleanJwk(jwk)
  // প্রাইভেট কী-তে 'verify' অ্যালাউড নয় (ওটা পাবলিক-কী অপ) — থাকলে SyntaxError
  const u = usages.filter((x) => x !== 'verify')
  if (c.crv === 'X25519') {
    if (!HOOKS.forceJsX25519) {
      try {
        const k = await crypto.subtle.importKey('jwk', c, X25519_ALG, false, u)
        jwkStore.set(k, c)
        return k
      } catch {
        // → JsKey (JWK-এ d থাকায় JS-গণনার জন্য যথেষ্ট)
      }
    }
    return jsKeyFromJwk(c, 'private', u)
  }
  const alg = u.includes('sign') ? SIGN_ALG : P256_DH_ALG
  const k = await crypto.subtle.importKey('jwk', c, alg, false, u)
  jwkStore.set(k, c)
  return k
}

export async function exportJwk(k: CryptoKey): Promise<JsonWebKey> {
  // JsKey বা রেজিস্ট্রিতে-থাকা কী → সঞ্চিত JWK-ই ফেরত (নেটিভ export
  // ব্যর্থ-প্রবণ পথে যাওয়ার দরকারই নেই)
  const hit = jwkStore.get(k)
  if (hit) return { ...hit }
  const jwk = await crypto.subtle.exportKey('jwk', k)
  jwkStore.set(k, jwk)
  return jwk
}

async function registerPairJwks(pair: CryptoKeyPair) {
  jwkStore.set(pair.privateKey, await crypto.subtle.exportKey('jwk', pair.privateKey))
  jwkStore.set(pair.publicKey, await crypto.subtle.exportKey('jwk', pair.publicKey))
}

// ডিফল্ট কার্ভ এখন সবসময় X25519 (pure-JS ফলব্যাক থাকায় সব ব্রাউজারে
// সম্ভব) — নতুন ইউজাররা সবাই একই কার্ভে, ইন্টারঅপ ঝামেলামুক্ত।
// স্পষ্ট crv আর্গুমেন্ট এলে (পিয়ার/লেগেসি-অ্যাডাপশন) সেটাই মানি।
export async function genDH(crv: DhCurve = HOOKS.regCurve): Promise<CryptoKeyPair> {
  if (crv === 'P-256') {
    const pair = await crypto.subtle.generateKey(P256_DH_ALG, true, ['deriveBits'])
    await registerPairJwks(pair)
    return pair
  }
  if (!HOOKS.forceJsX25519) {
    try {
      const pair = await crypto.subtle.generateKey(X25519_ALG, true, ['deriveBits'])
      try {
        await registerPairJwks(pair)
        return pair
      } catch {
        // জেনারেট হলেও JWK-এক্সপোর্ট ব্যর্থ (Firefox-জাতীয় কোরক) —
        // নেটিভ কীটা বাদ দিয়ে JS-কী নিই, তাহলে সব পরের-ধাপ নিশ্চিত।
      }
    } catch {
      // generateKey-ই নেই (পুরনো Edge/Chrome) → JS-কী
    }
  }
  const { priv, pub } = x25519Generate()
  const privJwk: JsonWebKey = { kty: 'OKP', crv: 'X25519', x: b64u(pub), d: b64u(priv), ext: true, key_ops: ['deriveBits'] }
  const pubJwk: JsonWebKey = { kty: 'OKP', crv: 'X25519', x: b64u(pub), ext: true, key_ops: [] }
  return {
    publicKey: new JsKey(pubJwk, 'public', []),
    privateKey: new JsKey(privJwk, 'private', ['deriveBits']),
  }
}

// ECDH — নেটিভ আগে, ব্যর্থ হলে pure-JS (X25519)। কার্ভ মিলছে না হলে
// স্পষ্ট এরর (x3dh-অ্যাডাপশন সাধারণত এটা আটকে দেয়)।
export async function dh(priv: CryptoKey, pub: CryptoKey): Promise<Uint8Array> {
  const pj = jwkStore.get(priv)
  const uj = jwkStore.get(pub)
  const pc = jwkCurve(pj)
  const uc = jwkCurve(uj)
  if (pc && uc && pc !== uc) {
    throw new Error(`ECDH curve mismatch: private=${pc}, public=${uc} — peer's key uses a different curve`)
  }
  const crv = pc || uc
  if (crv === 'X25519') {
    const useJs = HOOKS.forceJsX25519 || priv instanceof JsKey || pub instanceof JsKey
    if (!useJs) {
      try {
        return new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: pub }, priv, 256))
      } catch {
        // Firefox OperationError জাতীয় হঠাৎ-ব্যর্থতা → JS-পথে নামি
      }
    }
    if (!pj?.d || !uj?.x) throw new Error('X25519 key material unavailable (JWK d/x missing)')
    return x25519Shared(b64uToBytes(pj.d), b64uToBytes(uj.x))
  }
  // P-256: সব ব্রাউজারে নেটিভ-ই সোজা পথ
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: pub }, priv, 256))
}

// ডায়াগনস্টিকের জন্য: এই ব্রাউজারে WebCrypto-X25519 আছে কি না
let wcX25519Cache: boolean | null = null
export async function webcryptoX25519Ok(): Promise<boolean> {
  if (wcX25519Cache !== null) return wcX25519Cache
  if (HOOKS.forceJsX25519) { wcX25519Cache = false; return false }
  try {
    await crypto.subtle.generateKey(X25519_ALG, false, ['deriveBits'])
    wcX25519Cache = true
  } catch { wcX25519Cache = false }
  return wcX25519Cache
}

export interface IdentityBundle {
  identity: CryptoKeyPair      // X25519 (লেগেসিতে P-256)
  signing: CryptoKeyPair       // ECDSA P-256
  signedPrekey: CryptoKeyPair  // X25519 (লেগেসিতে P-256)
  spkSig: string               // base64url
  otks: CryptoKeyPair[]        // one-time prekeys
}

const K = { identity: 'identity', signing: 'signing', spk: 'signedPrekey', spkSig: 'spkSig', otks: 'otks' }

export async function createIdentityBundle(): Promise<IdentityBundle> {
  const [identity, signing, signedPrekey] = await Promise.all([genDH(), genSign(), genDH()])
  const spkJwk = await exportJwk(signedPrekey.publicKey)
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, signing.privateKey, new TextEncoder().encode(JSON.stringify(spkJwk)))
  const spkSig = b64u(sig)
  const otks = await Promise.all(Array.from({ length: 20 }, () => genDH()))
  const bundle: IdentityBundle = { identity, signing, signedPrekey, spkSig, otks }
  await persistBundle(bundle)
  return bundle
}

export async function persistBundle(b: IdentityBundle) {
  await idb.put('keys', K.identity, { pub: await exportJwk(b.identity.publicKey), priv: await exportJwk(b.identity.privateKey) })
  await idb.put('keys', K.signing, { pub: await exportJwk(b.signing.publicKey), priv: await exportJwk(b.signing.privateKey) })
  await idb.put('keys', K.spk, { pub: await exportJwk(b.signedPrekey.publicKey), priv: await exportJwk(b.signedPrekey.privateKey) })
  await idb.put('keys', K.spkSig, b.spkSig)
  await idb.put('keys', K.otks, await Promise.all(b.otks.map(async (k) => ({ pub: await exportJwk(k.publicKey), priv: await exportJwk(k.privateKey) }))))
}

export async function loadIdentityBundle(): Promise<IdentityBundle | null> {
  const identity = await idb.get('keys', K.identity)
  if (!identity) return null
  const [signing, spk, spkSig, otks] = await Promise.all([
    idb.get('keys', K.signing), idb.get('keys', K.spk), idb.get('keys', K.spkSig), idb.get('keys', K.otks),
  ])
  const toPair = async (o: any, usages: KeyUsage[]): Promise<CryptoKeyPair> => ({
    publicKey: await importPubJwk(o.pub, usages.includes('verify') ? ['verify'] : []),
    privateKey: await importPrivJwk(o.priv, usages),
  })
  return {
    identity: await toPair(identity, ['deriveBits']),
    signing: await toPair(signing, ['sign', 'verify']),
    signedPrekey: await toPair(spk, ['deriveBits']),
    spkSig,
    otks: await Promise.all((otks || []).map((o: any) => toPair(o, ['deriveBits']))),
  }
}

// সার্ভারে আপলোডের জন্য শুধুই পাবলিক অংশ
export async function publicBundleForUpload(b: IdentityBundle) {
  return {
    identityPub: await exportJwk(b.identity.publicKey),
    signPub: await exportJwk(b.signing.publicKey),
    spkPub: await exportJwk(b.signedPrekey.publicKey),
    spkSig: b.spkSig,
    otks: await Promise.all(b.otks.map((k) => exportJwk(k.publicKey))),
  }
}

export async function verifySignedPrekey(spkPub: JsonWebKey, sig: string, signPub: JsonWebKey): Promise<boolean> {
  try {
    const key = await importPubJwk(signPub, ['verify'])
    const sigBytes = (() => { const s = sig.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - sig.length % 4) % 4); const bin = atob(s); return Uint8Array.from([...bin].map((c) => c.charCodeAt(0))) })()
    return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sigBytes, new TextEncoder().encode(JSON.stringify(spkPub)))
  } catch { return false }
}
