// X25519 (RFC 7748) — pure-JS ইমপ্লিমেন্টেশন।
//
// 🩺 Round 22: WebCrypto-তে X25519 সাপোর্ট ব্রাউজারভেদে আলাদা — পুরনো
// Edge/Chrome (<133) "NotSupportedError: Unrecognized namedCurve" দেয়,
// কিছু Firefox বিল্ড "OperationError" দেয়। তাই ECDH-র এই pure-JS পথটি
// রাখা হলো — WebCrypto ব্যর্থ হলেই keys.ts এখানে নেমে আসে, ফলে
// এনক্রিপশন সব ব্রাউজারে কাজ করে। BigInt-ভিত্তিক, প্রতি ডিএইচ-গণনায়
// ~১-২ms — প্রতি মেসেজে এক-দুইবার লাগে বলে কার্যকর হিসেবে মুক্ত।
//
// নিরাপত্তা-নোট: WebCrypto-র মতো constant-time নয় (JS BigInt ব্রাঞ্চ
// করে) — কিন্তু আসল হুমকি-মডেল এখানে সার্ভার/নেটওয়ার্ক, লোকাল
// টাইমিং-অ্যাটাক নয়; আর আধুনিক ব্রাউজারে প্রধান পথ এখনো WebCrypto।

const P = (1n << 255n) - 19n          // 2^255 - 19
const A24 = 121665n                    // (486662 - 2) / 4
const BASE = (() => {                  // u = 9 (বেস-পয়েন্ট)
  const u = new Uint8Array(32)
  u[0] = 9
  return u
})()

const mod = (a: bigint): bigint => ((a % P) + P) % P

function leToBig(b: Uint8Array): bigint {
  let v = 0n
  for (let i = b.length - 1; i >= 0; i--) v = (v << 8n) | BigInt(b[i])
  return v
}

function bigToLe32(v: bigint): Uint8Array {
  const out = new Uint8Array(32)
  for (let i = 0; i < 32; i++) {
    out[i] = Number(v & 0xffn)
    v >>= 8n
  }
  return out
}

// স্ক্যালার "clamping" (RFC 7748 §5): উচ্চ/নিম্ন বিট ঠিক করা
function clampScalar(k: Uint8Array): Uint8Array {
  const b = new Uint8Array(k)
  if (b.length !== 32) throw new Error('x25519: scalar must be 32 bytes')
  b[0] &= 248
  b[31] &= 127
  b[31] |= 64
  return b
}

// মন্টগোমারি ল্যাডার (RFC 7748 §5) — X25519 স্ক্যালার-গুণন
export function x25519ScalarMult(k: Uint8Array, u: Uint8Array): Uint8Array {
  if (u.length !== 32) throw new Error('x25519: u-coordinate must be 32 bytes')
  const kS = leToBig(clampScalar(k))
  // u-র সর্বোচ্চ বিট উপেক্ষিত (RFC 7748 §5)
  const ub = new Uint8Array(u)
  ub[31] &= 127
  const x1 = leToBig(ub)

  let x2 = 1n, z2 = 0n
  let x3 = x1, z3 = 1n
  let swap = 0n

  for (let t = 254; t >= 0; t--) {
    const kT = (kS >> BigInt(t)) & 1n
    swap ^= kT
    if (swap === 1n) {
      const tx = x2; x2 = x3; x3 = tx
      const tz = z2; z2 = z3; z3 = tz
    }
    swap = kT

    const A = mod(x2 + z2)
    const AA = mod(A * A)
    const B = mod(x2 - z2)
    const BB = mod(B * B)
    const E = mod(AA - BB)
    const C = mod(x3 + z3)
    const D = mod(x3 - z3)
    const DA = mod(D * A)
    const CB = mod(C * B)
    const t0 = mod(DA + CB)
    x3 = mod(t0 * t0)
    const t1 = mod(DA - CB)
    z3 = mod(x1 * mod(t1 * t1))
    x2 = mod(AA * BB)
    z2 = mod(E * mod(AA + mod(A24 * E)))
  }
  if (swap === 1n) {
    const tx = x2; x2 = x3; x3 = tx
    const tz = z2; z2 = z3; z3 = tz
  }

  // x2 * z2^(p-2) mod p — ইনভার্সন (ফার্মাট)
  const zInv = mod(powMod(z2, P - 2n))
  return bigToLe32(mod(x2 * zInv))
}

function powMod(base: bigint, exp: bigint): bigint {
  let r = 1n
  let b = mod(base)
  let e = exp
  while (e > 0n) {
    if (e & 1n) r = mod(r * b)
    b = mod(b * b)
    e >>= 1n
  }
  return r
}

// প্রাইভেট-স্ক্যালার থেকে পাবলিক কী (বেস-পয়েন্ট u=9)
export function x25519PublicFromPrivate(priv: Uint8Array): Uint8Array {
  return x25519ScalarMult(priv, BASE)
}

// ECDH শেয়ার্ড সিক্রেট — সব-শূন্য আউটপুট = ডিজেনারেট/অবৈধ পাবলিক কী (RFC 7748 §6.1)
export function x25519Shared(priv: Uint8Array, peerPub: Uint8Array): Uint8Array {
  const out = x25519ScalarMult(priv, peerPub)
  let zero = true
  for (const b of out) if (b !== 0) { zero = false; break }
  if (zero) throw new Error('x25519: all-zero shared secret (invalid peer public key)')
  return out
}

// নতুন কী-জোড়া (clamped random scalar)
export function x25519Generate(): { priv: Uint8Array; pub: Uint8Array } {
  const priv = crypto.getRandomValues(new Uint8Array(32))
  priv[0] &= 248
  priv[31] &= 127
  priv[31] |= 64
  return { priv, pub: x25519PublicFromPrivate(priv) }
}
