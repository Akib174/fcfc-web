// X3DH-style প্রাথমিক কী-এক্সচেঞ্জ (Signal-inspired)।
// ইনিশিয়েটর: dh1=IKa×SPKb, dh2=EKa×IKb, dh3=EKa×SPKb, dh4=EKa×OPKb (থাকলে)
// ডাবল-র‍্যামচেট স্পেক অনুযায়ী একাধিক ডিভাইসের প্রথম হ্যান্ডশেকের জন্য
// এফেমেরাল কী-ই প্রথম র‍্যামচেট কী হিসেবে পুনর্ব্যবহার করা হয়েছে।
//
// 🩺 Round 22 — কার্ভ-অ্যাডাপশন: প্রেরক এখন প্রাপকের বান্ডেলের কার্ভেই
// (X25519 বা লেগেসি P-256) নিজের হ্যান্ডশেক-কী বানায়। নিজের আইডেন্টিটি
// ভিন্ন-কার্ভে থাকলে (পুরনো-বাগের-যুগের রেজিস্ট্রেশন) এই হ্যান্ডশেকের
// জন্য পিয়ারের কার্ভে তাৎক্ষণিক আইডেন্টিটি-জোড়া বানানো হয় — রিসিভার
// হ্যান্ডশেকের ik থেকেই গণনা করে, তাই দুই পক্ষ একই শেয়ার্ড সিক্রেটে
// পৌঁছায়, ব্রাউজার যে-কার্ভই সাপোর্ট করুক।
import { dh, genDH, importPrivJwk, importPubJwk, loadIdentityBundle, verifySignedPrekey, exportJwk, jwkCurve } from './keys'
import { hkdf } from './ratchet'

export interface PrekeyBundle {
  identityPub: JsonWebKey
  signPub: JsonWebKey
  spkPub: JsonWebKey
  spkSig: string
  opkPub: JsonWebKey | null
}

export interface Handshake { ik: JsonWebKey; ek: JsonWebKey; opk: JsonWebKey | null }

export interface X3dhResult {
  rootKey: Uint8Array
  dh3: Uint8Array // EKa×SPKb — প্রথম র‍্যামচেট স্টেপে পুনর্ব্যবহার হয়
  handshake: Handshake | null
  ekaPriv: JsonWebKey | null
  ekaPub: JsonWebKey | null
}

// পিয়ারের বান্ডেল/হ্যান্ডশেকের কার্ভ — অজানা হলে X25519-ই ডিফল্ট
function curveOf(jwk: JsonWebKey | null | undefined): 'X25519' | 'P-256' {
  return jwkCurve(jwk) === 'P-256' ? 'P-256' : 'X25519'
}

// JWK-তুলনা ক্ষেত্র-ক্রম-নিরপেক্ষভাবে (কেবল অর্থবহ অংশগুলো)
function jwkId(j: JsonWebKey): string {
  return JSON.stringify({ kty: j.kty, crv: j.crv, x: j.x })
}

export async function x3dhInitiate(their: PrekeyBundle): Promise<X3dhResult> {
  if (!(await verifySignedPrekey(their.spkPub, their.spkSig, their.signPub))) {
    throw new Error('signed prekey signature invalid')
  }
  const me = await loadIdentityBundle()
  if (!me) throw new Error('identity not ready')

  // পিয়ারের কার্ভেই সব হ্যান্ডশেক-কী
  const crv = curveOf(their.spkPub)
  const myIkCrv = curveOf(await exportJwk(me.identity.publicKey))
  // নিজের আইডেন্টিটি ভিন্ন কার্ভে হলে এই হ্যান্ডশেকের জন্য পিয়ারের
  // কার্ভে তাৎক্ষণিক জোড়া — রিসিভার হ্যান্ডশেকের ik-ই ব্যবহার করে
  const ikPair = myIkCrv === crv ? me.identity : await genDH(crv)

  const ek = await genDH(crv)
  const ekPriv = await exportJwk(ek.privateKey)
  const ekPub = await exportJwk(ek.publicKey)

  const ikB = await importPubJwk(their.identityPub)
  const spkB = await importPubJwk(their.spkPub)
  const ekKey = await importPrivJwk(ekPriv, ['deriveBits'])

  const dh1 = await dh(ikPair.privateKey, spkB)
  const dh2 = await dh(ekKey, ikB)
  const dh3 = await dh(ekKey, spkB)
  const parts = [dh1, dh2, dh3]
  // ওয়ান-টাইম প্রিকি পিয়ারের মূল কার্ভেই থাকতে হবে — মিশ্র-কার্ভ
  // বান্ডেলে ভুল কার্ভের ওটিকে নিরাপদে উপেক্ষা (৩-অংশের সিক্রেট হয়)
  const opkUsable = their.opkPub && jwkCurve(their.opkPub) === crv ? their.opkPub : null
  if (opkUsable) {
    const opkB = await importPubJwk(opkUsable)
    parts.push(await dh(ekKey, opkB))
  }
  const concat = new Uint8Array(parts.reduce((a, p) => a + p.length, 0))
  let off = 0
  for (const p of parts) { concat.set(p, off); off += p.length }
  const rootKey = await hkdf(new Uint8Array(32), concat, 'fcfc-x3dh', 32)

  const ikPub = await exportJwk(ikPair.publicKey)
  return {
    rootKey,
    dh3,
    handshake: { ik: ikPub, ek: ekPub, opk: opkUsable },
    ekaPriv: ekPriv,
    ekaPub: ekPub,
  }
}

// রিসিভার সাইড: হ্যান্ডশেক দেখে নিজের দিকের শেয়ার্ড সিক্রেট বানানো
export async function x3dhRespond(hs: Handshake): Promise<{ rootKey: Uint8Array; dh3Shared: Uint8Array }> {
  const me = await loadIdentityBundle()
  if (!me) throw new Error('identity not ready')
  const ikA = await importPubJwk(hs.ik)
  const ekA = await importPubJwk(hs.ek)

  const dh1 = await dh(me.signedPrekey.privateKey, ikA)
  const dh2 = await dh(me.identity.privateKey, ekA)
  const dh3 = await dh(me.signedPrekey.privateKey, ekA)
  const parts = [dh1, dh2, dh3]

  if (hs.opk) {
    // ব্যবহৃত ওয়ান-টাইম প্রিকিটি লোকাল তালিকা থেকে খুঁজে বের করা
    // (ক্ষেত্র-ক্রম/বাহ্যিক-ক্ষেত্র-পার্থক্যে ভুল মিস যেন না হয় —
    // শুধু kty/crv/x তুলনা)
    const opkId = jwkId(hs.opk)
    let found = false
    for (const otk of me.otks) {
      const pub = await exportJwk(otk.publicKey)
      if (jwkId(pub) === opkId) {
        parts.push(await dh(otk.privateKey, ekA))
        found = true
        break
      }
    }
    // প্রিকি না পেলে আগে নীরবে ৩-অংশের সিক্রেট বানানো হতো — ইনিশিয়েটরের
    // ৪-অংশের সাথে মিলত না, সেশনটা চিরকালের জন্য ভাঙা থাকত। এখন স্পষ্ট এরর।
    if (!found) throw new Error('one-time prekey not found locally (rotated/restored backup?)')
  }
  const concat = new Uint8Array(parts.reduce((a, p) => a + p.length, 0))
  let off = 0
  for (const p of parts) { concat.set(p, off); off += p.length }
  const rootKey = await hkdf(new Uint8Array(32), concat, 'fcfc-x3dh', 32)
  return { rootKey, dh3Shared: dh3 }
}
