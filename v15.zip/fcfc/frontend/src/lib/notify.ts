// লোকাল/পুশ নোটিফিকেশন হেল্পার + নোটিফিকেশন সাউন্ড (সিন্থেসাইজড পিং)।
import type { Chat, Message } from '../types'
import { useChats } from '../stores/chats'
import { t } from '../lib/i18n'

export function chatTitle(c: Chat): string {
  // 📌 Saved Messages — নিজের সাথে self-chat (Telegram-স্টাইল)
  if (c.saved) return t('savedChatTitle')
  if (c.kind === 'group') return c.title || t('groupFallback')
  // 🆕 ডিসপ্লে-নেম থাকলে সেটাই (না থাকলে username) — চ্যাটে নাম হিসেবে দেখায়
  return c.peer?.deleted ? t('deletedAccount') : c.peer?.name || c.peer?.username || t('chatFallback')
}

export function notifyMessage(chat: Chat, msg: Message) {
  try {
    if (!('Notification' in window)) return
    if (Notification.permission !== 'granted') return
    // অ্যাপ ফোকাসে ও একই চ্যাট খোলা থাকলে ট্রে-তে দেখানোর দরকার নেই।
    // (অ্যাপটি হ্যাশ-ভিত্তিক — আগে location.search দেখা হতো, যা কখনোই ম্যাচ করত না)
    if (document.hasFocus() && useChats.getState().activeChatId === msg.chatId) return
    const title = chatTitle(chat)
    const body = msg.body || t('encryptedMsgBody')
    new Notification(title, {
      body: body.slice(0, 120),
      tag: `msg-${msg.id}`,
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      data: { chatId: msg.chatId },
    })
  } catch {}
}

export async function requestNotifyPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false
  if (Notification.permission === 'default') await Notification.requestPermission()
  return Notification.permission === 'granted'
}

let audioCtx: AudioContext | null = null
// অটোপ্লে-পলিসি: AudioContext প্রথম ইনকামিং মেসেজে (ইউজার-জেসচার ছাড়া)
// তৈরি হলে "suspended" থেকে যায় — পিং নীরব থাকত। প্রথম ইন্টারঅ্যাকশনে আনলক।
try {
  const unlock = () => {
    try {
      audioCtx = audioCtx || new AudioContext()
      void audioCtx.resume()
    } catch {}
    window.removeEventListener('pointerdown', unlock)
    window.removeEventListener('keydown', unlock)
  }
  window.addEventListener('pointerdown', unlock)
  window.addEventListener('keydown', unlock)
} catch {}

// ── 🔔 নোটিফিকেশন-সাউন্ড — iPhone "ট্রাই-টোন"-স্টাইল ──
// তিনটা বেল-টোন (দুটো ছোট + শেষটা লম্বা, রিং-হয়ে মিলিয়ে যায়):
// D5 → G♯5 (ট্রাইটোন ব্যবধান — নামেরই মানে) → D6। আগের সিন্থ-পিং
// (880→1318Hz এক-টোন) এর বদলে এখন Apple-অ্যালার্টের চেহারা।
function bellNote(ctx: AudioContext, freq: number, at: number, dur: number, vol: number) {
  const gain = ctx.createGain()
  gain.connect(ctx.destination)
  gain.gain.setValueAtTime(0.0001, at)
  gain.gain.exponentialRampToValueAtTime(vol, at + 0.008)
  gain.gain.exponentialRampToValueAtTime(0.0001, at + dur)
  // ফান্ডামেন্টাল + অকটেভ-পার্শিয়াল + হালকা ডিটিউন = বেল/গ্লাস টিম্ব্রে
  for (const [f, v] of [[freq, 1], [freq * 2, 0.28], [freq * 2.01, 0.1]] as [number, number][]) {
    const osc = ctx.createOscillator()
    osc.type = 'sine'
    osc.frequency.value = f
    const g2 = ctx.createGain()
    g2.gain.value = v
    osc.connect(g2).connect(gain)
    osc.start(at)
    osc.stop(at + dur + 0.05)
  }
}

export function playPing() {
  try {
    audioCtx = audioCtx || new AudioContext()
    if (audioCtx.state === 'suspended') void audioCtx.resume()
    const t = audioCtx.currentTime
    // ট্রাই-টোন: দ্রুত দুটো নোট + শেষ নোট রিং-করে থাকে
    bellNote(audioCtx, 587.33, t + 0.0, 0.18, 0.14)   // D5
    bellNote(audioCtx, 830.61, t + 0.16, 0.18, 0.14)  // G♯5
    bellNote(audioCtx, 1174.66, t + 0.32, 0.75, 0.2)  // D6
  } catch {}
}

// ── 🔴 লাল-ভয়েস অটো-প্লে (Web-Audio পাথ) ─────────────────────────
// পিং/রিংটোনের মতোই আনলকড AudioContext দিয়ে বাজানো হয়। নতুন
// new Audio(url).play() ব্রাউজারের অটোপ্লে-পলিসিতে ব্লক হয়
// (NotAllowedError) — ব্যাকগ্রাউন্ড ট্যাব/লকড ফোন/নতুন লোডে
// পিয়ারের কোনো রিসেন্ট-জেসচার না থাকলে সাউন্ডই আসত না। আনলকড
// AudioContext দিয়ে decodeAudioData + BufferSource চালালে জেসচার
// ছাড়াই বাজে (প্রথম টাচে উপরের unlock-লিসেনার ctx চালু করে রাখে)।
export function getAudioCtx(): AudioContext | null {
  try {
    audioCtx = audioCtx || new AudioContext()
    return audioCtx
  } catch { return null }
}

let curVoiceSrc: AudioBufferSourceNode | null = null

// চলমান অটো-ভয়েস থামানো (নতুন লাল-ভয়েস এলে আগেরটা বন্ধ — ওভারল্যাপ এড়াতে)
export function stopVoicePlayback() {
  try { curVoiceSrc?.stop() } catch {}
  curVoiceSrc = null
}

// url (blob:) কে আনলকড AudioContext দিয়ে বাজায়। সফল হলে true।
// ctx না খোলা/suspended হলে false — কলার তখন <audio> ফলব্যাকে যাবে।
export async function playVoiceThroughCtx(url: string): Promise<boolean> {
  try {
    const ctx = getAudioCtx()
    if (!ctx || ctx.state !== 'running') return false
    const buf = await (await fetch(url)).arrayBuffer()
    // নতুন প্রমিজ-ভার্সন + পুরনো Safari-র কলব্যাক-ভার্সন দুটোই ধরা হলো
    const decoded: AudioBuffer = await new Promise((res, rej) => {
      try {
        const p: any = (ctx as any).decodeAudioData(buf, res, rej)
        if (p && typeof p.then === 'function') p.then(res, rej)
      } catch (e) { rej(e) }
    })
    stopVoicePlayback()
    const src = ctx.createBufferSource()
    const gain = ctx.createGain()
    gain.gain.value = 1
    src.buffer = decoded
    src.connect(gain).connect(ctx.destination)
    src.start()
    curVoiceSrc = src
    src.onended = () => { if (curVoiceSrc === src) curVoiceSrc = null }
    return true
  } catch { return false }
}

// ── 📞 ইনকামিং-কল রিংটোন — iPhone "মারিম্বা"-স্টাইল ──
// মারিম্বা-টিম্ব্রে (ফান্ডামেন্টাল + ৪র্থ-হারমোনিক ফাস্ট-ডিকে) মোটিফ
// একবার বাজে → ~২ সেকেন্ড নীরব → আবার (আসল রিংটোনের মতো লুপ)।
// stop() না ডাকলে চলতেই থাকে।
function marimbaNote(ctx: AudioContext, freq: number, at: number, dur: number, vol: number) {
  const gain = ctx.createGain()
  gain.connect(ctx.destination)
  gain.gain.setValueAtTime(0.0001, at)
  gain.gain.exponentialRampToValueAtTime(vol, at + 0.005)
  gain.gain.exponentialRampToValueAtTime(0.0001, at + dur)
  // মারিম্বা: ফান্ডামেন্টাল ডান, ৪র্থ হারমোনিক দ্রুত মিলিয়ে যায় ("স্ট্রাক")
  for (const [f, v, d] of [[freq, 1, dur], [freq * 4, 0.18, dur * 0.35]] as [number, number, number][]) {
    const osc = ctx.createOscillator()
    osc.type = 'sine'
    osc.frequency.value = f
    const g2 = ctx.createGain()
    g2.gain.value = v
    osc.connect(g2).connect(gain)
    osc.start(at)
    osc.stop(at + d + 0.05)
  }
}

// মোটিফ (E5 E5 E5 · G5 G5 E5 · C6 D6) — iPhone-ডিফল্ট রিংটোনের ছন্দ-অনুভূতি
const MARIMBA_MELODY: [number, number, number][] = [
  [659.25, 0.00, 0.22],  // E5
  [659.25, 0.22, 0.22],  // E5
  [659.25, 0.44, 0.22],  // E5
  [783.99, 0.66, 0.30],  // G5
  [783.99, 0.98, 0.30],  // G5
  [659.25, 1.30, 0.30],  // E5
  [1046.50, 1.62, 0.30], // C6
  [1174.66, 1.94, 0.70], // D6 (ধরে রাখা)
]
const MARIMBA_MELODY_DUR = 2.75 // সেকেন্ড — মোটিফের দৈর্ঘ্য

// ── 📞 আসল iPhone রিংটোন — লোকাল ফাইল (public/sounds/) ──
// Apple-এর আসল রিংটোন: Marimba (2007-ক্লাসিক, প্রাথমিক) + Opening
// (মডার্ন ডিফল্ট, ফলব্যাক)। অ্যানলকড AudioContext দিয়ে decodeAudioData →
// BufferSource (loop) — জেসচার ছাড়াই বাজে (ভয়েস-অটো-প্লে-পাথের মতোই)।
// ☁️ Cloudflare-ডিপ্লয়-নিরাপদ: static asset (<1MB) — Worker assets-এর
//    ২০MiB/ফাইল সীমার অনেক নিচে; কোনো এক্সট্রা কনফিগ লাগে না।
const RINGTONE_URLS = ['/sounds/marimba.mp3', '/sounds/opening.mp3']
let ringtoneBuf: AudioBuffer | null = null
let ringtoneTried = false

async function loadRingtoneBuffer(ctx: AudioContext): Promise<AudioBuffer | null> {
  if (ringtoneBuf) return ringtoneBuf
  if (ringtoneTried) return null
  ringtoneTried = true
  for (const url of RINGTONE_URLS) {
    try {
      const res = await fetch(url)
      if (!res.ok) continue
      const buf = await res.arrayBuffer()
      // নতুন প্রমিজ-ভার্সন + পুরনো Safari-র কলব্যাক-ভার্সন দুটোই ধরা হলো
      const decoded: AudioBuffer = await new Promise((res2, rej) => {
        try {
          const p: any = (ctx as any).decodeAudioData(buf, res2, rej)
          if (p && typeof p.then === 'function') p.then(res2, rej)
        } catch (e) { rej(e) }
      })
      ringtoneBuf = decoded
      return decoded
    } catch {}
  }
  return null
}

export function startRingtone(): () => void {
  let stopped = false
  let vibrateTimer: any = null
  let synthTimer: any = null
  let fallbackDelay: any = null
  let started = false
  let src: AudioBufferSourceNode | null = null
  try {
    audioCtx = audioCtx || new AudioContext()
    if (audioCtx.state === 'suspended') void audioCtx.resume()
    const ctx = audioCtx

    const stopAll = () => {
      stopped = true
      try { src?.stop() } catch {}
      src = null
      if (synthTimer) clearInterval(synthTimer)
      if (fallbackDelay) clearTimeout(fallbackDelay)
      if (vibrateTimer) clearInterval(vibrateTimer)
      try { navigator.vibrate(0) } catch {}
    }

    // 🎵 আসল-রিংটোন পাথ — লোড হতে এক-দুই সেকেন্ড লাগতে পারে (প্রথমবার);
    // শুরু হলেই লুপ-মোডে চলতে থাকে (আসল ফোনের মতো রিং রিং রিং…)।
    loadRingtoneBuffer(ctx).then((buf) => {
      if (stopped || started || !buf) return
      try {
        started = true
        if (synthTimer) { clearInterval(synthTimer); synthTimer = null } // ফলব্যাক বন্ধ
        src = ctx.createBufferSource()
        src.buffer = buf
        src.loop = true
        const gain = ctx.createGain()
        gain.gain.value = 1 // 🔊 লাউড — ফাইলটা নিজেই লাউড-মাস্টারড
        src.connect(gain).connect(ctx.destination)
        src.start()
      } catch { src = null; started = false }
    }).catch(() => {})

    // 🧯 ফলব্যাক — ২.২ সেকেন্ডেও ফাইল-রিং শুরু না হলে সিন্থ-মারিম্বা; আসল
    // রিংটোন পরে লোড-সফল হলে সেটা নিজেই ফলব্যাকটা বন্ধ করে নেয়।
    fallbackDelay = setTimeout(() => {
      if (stopped || started) return
      const loop = () => {
        if (stopped || started) { clearInterval(synthTimer); return }
        const t = ctx.currentTime + 0.05
        for (const [f, at, d] of MARIMBA_MELODY) marimbaNote(ctx, f, t + at, d, 0.25)
      }
      loop()
      synthTimer = setInterval(loop, (MARIMBA_MELODY_DUR + 2) * 1000)
    }, 2200)

    // মোবাইলে ভাইব্রেশন-ও (যেখানে সাপোর্টেড) — রিং-লুপের সাথে মোটামুটি সিঙ্কে
    try {
      if (navigator.vibrate) {
        navigator.vibrate([600, 200, 600, 3350])
        vibrateTimer = setInterval(() => { if (!stopped) navigator.vibrate([600, 200, 600, 3350]) }, 4750)
      }
    } catch {}
    return stopAll
  } catch {
    return () => {}
  }
}
