-- fcfc migration 0005 — group management features:
--  • owner-initiated group delete (soft: members keep read-only history)
--  • group permissions: who can send messages, who can delete-for-everyone

-- ওনার গ্রুপ ডিলিট করলে 1 — মেম্বারদের লিস্টে চ্যাট থেকে যায় (read-only),
-- "Owner deleted" সাবটাইটেল দেখায়, নতুন মেসেজ বন্ধ।
ALTER TABLE chats ADD COLUMN deleted INTEGER DEFAULT 0;

-- কে মেসেজ পাঠাতে পারবে: 'all' (সব মেম্বার) | 'admins' (শুধু অ্যাডমিন/ওনার)
ALTER TABLE chats ADD COLUMN perm_send TEXT DEFAULT 'all';

-- "Delete for everyone" পারমিশন: 'own' (শুধু নিজের মেসেজ) | 'members'
-- ('members' = সবাই যে-কারো মেসেজ ডিলিট পারবে — অ্যাডমিনদেরটা নয়;
--   অ্যাডমিন যে-কারোটা পারবে (অন্য অ্যাডমিনের নয়); ওনার সবগুলোই পারবে।)
ALTER TABLE chats ADD COLUMN perm_delete TEXT DEFAULT 'own';
